package com.example.login

data class LoginResponse(
	val userId: Int?,
	val token: String?,
)
