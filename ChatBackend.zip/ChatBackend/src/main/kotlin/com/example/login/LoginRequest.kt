package com.example.login

data class LoginRequest(
    val username: String,
    val password: String,
)