package com.example.contact

data class ContactPostResponse(
	val error: String?,
)