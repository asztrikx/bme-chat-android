package com.example.message

data class NewMessage(
	val contactId: Int,
	val content: String,
)