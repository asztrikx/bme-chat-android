package com.example.register

data class RegisterRequest(
	val username: String,
	val password: String,
	val name: String,
)