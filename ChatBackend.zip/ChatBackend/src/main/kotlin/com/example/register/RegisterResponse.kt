package com.example.register

data class RegisterResponse(
	val errorMessage: String?,
)